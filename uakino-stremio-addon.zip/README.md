# UAKINO Stremio Add-on

Неофіційний Stremio add-on для перегляду україномовних фільмів та серіалів з uakino.me.

## Як запустити

1. Встановити залежності:

```
npm install
```

2. Запустити локально:

```
node index.js
```

3. Або залити на Render / Replit і використовувати URL до manifest.json у Stremio.